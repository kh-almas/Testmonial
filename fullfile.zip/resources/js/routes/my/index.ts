import observations from './observations'
const my = {
    observations: Object.assign(observations, observations),
}

export default my