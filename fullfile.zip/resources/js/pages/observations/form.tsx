import { useState, type FormEvent } from 'react';
import { Head, Link, useForm } from '@inertiajs/react';

type ResearchKey =
    | 'diseases'
    | 'organs'
    | 'systems'
    | 'administration_methods'
    | 'research_topics'
    | 'keywords'
    | 'biomarkers';

type ResearchSelections = Record<ResearchKey, string[]>;

type ResearchGroup = {
    key: ResearchKey;
    label: string;
    options: Array<{ id: string; label: string }>;
};

type Observation = {
    id: number;
    status: string;
    title: string | null;
    observation: string | null;
    condition_symptom_text: string | null;
    duration_text: string | null;
    frequency_text: string | null;
    timeline_text: string | null;
    research: ResearchSelections;
};

type HistoryEntry = {
    action: string;
    comment: string | null;
    date: string;
};

type Props = {
    observation: Observation | null;
    groups: ResearchGroup[];
    emptySelections: ResearchSelections;
    history: HistoryEntry[];
    notice?: string | null;
};

function ResearchPicker({
                            group,
                            selected,
                            disabled,
                            onChange,
                        }: {
    group: ResearchGroup;
    selected: string[];
    disabled: boolean;
    onChange: (selectedIds: string[]) => void;
}) {
    const [search, setSearch] = useState('');

    const visibleOptions = group.options.filter((option) =>
        option.label.toLowerCase().includes(search.toLowerCase()),
    );

    function toggleOption(optionId: string) {
        onChange(
            selected.includes(optionId)
                ? selected.filter((selectedId) => selectedId !== optionId)
                : [...selected, optionId],
        );
    }

    return (
        <details className="rounded-xl border border-slate-200 bg-white">
            <summary className="cursor-pointer p-4 font-medium text-slate-800">
                {group.label}
                <span className="ml-2 rounded-full bg-cyan-50 px-2 py-1 text-xs text-cyan-800">
                    {selected.length} selected
                </span>
            </summary>

            <div className="space-y-3 border-t border-slate-100 p-4">
                <div className="flex gap-2">
                    <input
                        type="search"
                        aria-label={`Search ${group.label}`}
                        placeholder={`Find ${group.label.toLowerCase()}`}
                        value={search}
                        onChange={(event) => setSearch(event.target.value)}
                        className="min-w-0 flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm"
                    />
                    {search && (
                        <button
                            type="button"
                            onClick={() => setSearch('')}
                            className="text-sm text-cyan-700"
                        >
                            Clear
                        </button>
                    )}
                </div>

                <div className="max-h-48 space-y-2 overflow-auto">
                    {visibleOptions.map((option) => (
                        <label
                            key={option.id}
                            className="flex cursor-pointer items-start gap-2 text-sm text-slate-700"
                        >
                            <input
                                type="checkbox"
                                checked={selected.includes(option.id)}
                                disabled={disabled}
                                onChange={() => toggleOption(option.id)}
                                className="mt-0.5 accent-cyan-700"
                            />
                            {option.label}
                        </label>
                    ))}
                    {visibleOptions.length === 0 && (
                        <p className="text-sm text-slate-500">
                            No matching options.
                        </p>
                    )}
                </div>
            </div>
        </details>
    );
}

export default function ObservationForm({
                                            observation,
                                            groups,
                                            emptySelections,
                                            history,
                                            notice,
                                        }: Props) {
    const editing = observation !== null;
    const canEdit =
        !observation
        || observation.status === 'draft'
        || observation.status === 'changes_requested';

    const form = useForm({
        title: observation?.title ?? '',
        observation: observation?.observation ?? '',
        condition_symptom_text: observation?.condition_symptom_text ?? '',
        duration_text: observation?.duration_text ?? '',
        frequency_text: observation?.frequency_text ?? '',
        timeline_text: observation?.timeline_text ?? '',
        research: observation?.research ?? emptySelections,
    });

    const fields = [
        { name: 'title', label: 'Observation title', multiline: false },
        {
            name: 'condition_symptom_text',
            label: 'Condition or symptom',
            multiline: false,
        },
        { name: 'duration_text', label: 'Duration', multiline: false },
        { name: 'frequency_text', label: 'Frequency', multiline: false },
        { name: 'timeline_text', label: 'Timeline', multiline: true },
        { name: 'observation', label: 'What did you observe?', multiline: true },
    ] as const;

    function saveDraft(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        if (observation) {
            form.put(`/my/observations/${observation.id}`, {
                onSuccess: () => form.setDefaults(),
            });
        } else {
            form.post('/my/observations');
        }
    }

    return (
        <>
            <Head
                title={editing ? 'My Observation' : 'New Observation'}
            />

            <main className="mx-auto max-w-5xl space-y-6 px-4 py-8 sm:px-6">
                <Link
                    href="/my/observations"
                    className="text-sm font-medium text-cyan-700 hover:underline"
                >
                    ← My Observations
                </Link>

                <header className="rounded-2xl bg-slate-950 px-6 py-8 text-white shadow-lg sm:px-8">
                    <p className="text-sm font-semibold text-cyan-300">
                        H2Stories · Personal observations
                    </p>
                    <h1 className="mt-2 text-3xl font-bold">
                        {editing ? 'Your observation' : 'New observation'}
                    </h1>
                    <p className="mt-2 text-sm text-slate-300">
                        Capture the details now. Only you can see this draft.
                    </p>
                </header>

                {notice && (
                    <p
                        role="status"
                        className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800"
                    >
                        {notice}
                    </p>
                )}

                {observation && (
                    <p className="rounded-lg border border-slate-200 bg-slate-50 p-4 text-sm text-slate-700">
                        Status: {observation.status.replaceAll('_', ' ')}
                        {!canEdit && ' · This version is read-only.'}
                    </p>
                )}

                <form onSubmit={saveDraft} className="space-y-6">
                    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
                        <h2 className="text-lg font-semibold text-slate-900">
                            Your account of what happened
                        </h2>
                        <p className="mb-6 mt-1 text-sm text-slate-500">
                            You can leave fields empty while drafting.
                        </p>

                        <div className="grid gap-5 sm:grid-cols-2">
                            {fields.map((field) => (
                                <div
                                    key={field.name}
                                    className={
                                        field.multiline ? 'sm:col-span-2' : ''
                                    }
                                >
                                    <label
                                        htmlFor={field.name}
                                        className="mb-2 block text-sm font-medium text-slate-800"
                                    >
                                        {field.label}
                                    </label>

                                    {field.multiline ? (
                                        <textarea
                                            id={field.name}
                                            value={form.data[field.name]}
                                            disabled={!canEdit}
                                            onChange={(event) =>
                                                form.setData(
                                                    field.name,
                                                    event.target.value,
                                                )
                                            }
                                            rows={
                                                field.name === 'observation'
                                                    ? 7
                                                    : 3
                                            }
                                            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                                        />
                                    ) : (
                                        <input
                                            id={field.name}
                                            type="text"
                                            value={form.data[field.name]}
                                            disabled={!canEdit}
                                            onChange={(event) =>
                                                form.setData(
                                                    field.name,
                                                    event.target.value,
                                                )
                                            }
                                            className="w-full rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900"
                                        />
                                    )}

                                    {form.errors[field.name] && (
                                        <p className="mt-1 text-sm text-rose-700">
                                            {form.errors[field.name]}
                                        </p>
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>

                    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
                        <h2 className="text-lg font-semibold text-slate-900">
                            Related research
                        </h2>
                        <p className="mb-5 mt-1 text-sm text-slate-500">
                            Select existing H2Research entries. You will need
                            at least one administration method when submission
                            is enabled.
                        </p>

                        <div className="grid gap-3 sm:grid-cols-2">
                            {groups.map((group) => (
                                <ResearchPicker
                                    key={group.key}
                                    group={group}
                                    selected={form.data.research[group.key]}
                                    disabled={!canEdit}
                                    onChange={(selectedIds) =>
                                        form.setData('research', {
                                            ...form.data.research,
                                            [group.key]: selectedIds,
                                        })
                                    }
                                />
                            ))}
                        </div>

                        {form.errors.research && (
                            <p className="mt-3 text-sm text-rose-700">
                                {form.errors.research}
                            </p>
                        )}
                    </section>

                    {canEdit && (
                        <div className="flex flex-wrap items-center justify-end gap-3">
                            {form.isDirty && editing && (
                                <span className="text-sm text-amber-700">
                                    Unsaved changes
                                </span>
                            )}
                            {form.recentlySuccessful && (
                                <span role="status" className="text-sm text-emerald-700">
                                    Saved
                                </span>
                            )}
                            <button
                                type="submit"
                                disabled={form.processing}
                                className="rounded-lg bg-slate-950 px-6 py-3 text-sm font-semibold text-white hover:bg-slate-800 disabled:opacity-50"
                            >
                                {form.processing ? 'Saving…' : 'Save draft'}
                            </button>
                        </div>
                    )}
                </form>

                {history.length > 0 && (
                    <section className="rounded-2xl border border-slate-200 bg-white p-5 shadow-sm sm:p-7">
                        <h2 className="text-lg font-semibold text-slate-900">
                            Activity
                        </h2>
                        <div className="mt-4 space-y-4">
                            {history.map((entry, entryIndex) => (
                                <div
                                    key={`${entry.action}-${entry.date}-${entryIndex}`}
                                    className="border-l-2 border-cyan-300 pl-4 text-sm"
                                >
                                    <p className="font-medium capitalize text-slate-800">
                                        {entry.action.replaceAll('_', ' ')}
                                    </p>
                                    <p className="text-slate-500">
                                        {new Date(entry.date).toLocaleString()}
                                    </p>
                                    {entry.comment && (
                                        <p className="mt-1 text-slate-700">
                                            {entry.comment}
                                        </p>
                                    )}
                                </div>
                            ))}
                        </div>
                    </section>
                )}
            </main>
        </>
    );
}
