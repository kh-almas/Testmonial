import { useEffect, useState, type FormEvent } from 'react';
import { Head, Link, router } from '@inertiajs/react';

type ObservationRow = {
    id: number;
    title: string | null;
    status: string;
    updated_at: string;
};

type PageLink = {
    url: string | null;
    label: string;
    active: boolean;
};

type Props = {
    observations: {
        data: ObservationRow[];
        links: PageLink[];
        from: number | null;
        to: number | null;
        total: number;
    };
    filters: { search: string };
    notice?: string | null;
};

const statusStyles: Record<string, string> = {
    draft: 'bg-sky-50 text-sky-800',
    pending_review: 'bg-amber-50 text-amber-800',
    changes_requested: 'bg-orange-50 text-orange-800',
    resubmitted: 'bg-violet-50 text-violet-800',
    approved: 'bg-emerald-50 text-emerald-800',
    published: 'bg-emerald-50 text-emerald-800',
    rejected: 'bg-rose-50 text-rose-800',
    archived: 'bg-slate-100 text-slate-600',
};

export default function MyObservations({
                                           observations,
                                           filters,
                                           notice,
                                       }: Props) {
    const [search, setSearch] = useState(filters.search);

    useEffect(() => {
        setSearch(filters.search);
    }, [filters.search]);

    function submitSearch(event: FormEvent<HTMLFormElement>) {
        event.preventDefault();

        const value = search.trim();

        router.get(
            '/my/observations',
            value ? { search: value } : {},
            { replace: true },
        );
    }

    function clearSearch() {
        setSearch('');
        router.get('/my/observations', {}, { replace: true });
    }

    function archiveDraft(observation: ObservationRow) {
        if (!window.confirm('Archive this draft? It will remain in your history.')) {
            return;
        }

        router.patch(`/my/observations/${observation.id}/archive`);
    }

    const previous = observations.links[0];
    const next = observations.links[observations.links.length - 1];

    return (
        <>
            <Head title="My Observations" />

            <main className="mx-auto max-w-6xl space-y-6 px-4 py-8 sm:px-6">
                <header className="rounded-2xl bg-slate-950 px-6 py-8 text-white shadow-lg sm:px-8">
                    <div className="flex flex-wrap items-end justify-between gap-5">
                        <div>
                            <p className="text-sm font-semibold text-cyan-300">
                                H2Stories · Your workspace
                            </p>
                            <h1 className="mt-2 text-3xl font-bold">
                                My Observations
                            </h1>
                            <p className="mt-2 text-sm text-slate-300">
                                Record what happened and keep your drafts in one place.
                            </p>
                        </div>

                        <Link
                            href="/my/observations/create"
                            className="rounded-lg bg-cyan-400 px-5 py-3 text-sm font-semibold text-slate-950 hover:bg-cyan-300"
                        >
                            New observation
                        </Link>
                    </div>
                </header>

                {notice && (
                    <p
                        role="status"
                        className="rounded-lg border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-800"
                    >
                        {notice}
                    </p>
                )}

                <section className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
                    <div className="flex flex-wrap items-center justify-between gap-4 border-b border-slate-200 p-5">
                        <div>
                            <h2 className="font-semibold text-slate-900">
                                Your observations
                            </h2>
                            <p className="text-sm text-slate-500">
                                {observations.total} total
                            </p>
                        </div>

                        <form
                            onSubmit={submitSearch}
                            className="flex w-full flex-wrap gap-2 sm:w-auto"
                        >
                            <input
                                type="search"
                                aria-label="Search observations"
                                placeholder="Search by title"
                                value={search}
                                onChange={(event) => setSearch(event.target.value)}
                                className="min-w-48 flex-1 rounded-lg border border-slate-300 px-3 py-2 text-sm text-slate-900 sm:flex-none"
                            />
                            <button
                                type="submit"
                                className="rounded-lg bg-slate-900 px-4 py-2 text-sm font-medium text-white"
                            >
                                Search
                            </button>
                            {(search || filters.search) && (
                                <button
                                    type="button"
                                    onClick={clearSearch}
                                    className="rounded-lg border border-slate-300 px-4 py-2 text-sm text-slate-700"
                                >
                                    Clear
                                </button>
                            )}
                        </form>
                    </div>

                    {observations.data.length === 0 ? (
                        <div className="p-10 text-center text-sm text-slate-500">
                            {filters.search
                                ? 'No observations match your search.'
                                : 'Create your first observation to get started.'}
                        </div>
                    ) : (
                        <div className="divide-y divide-slate-100">
                            {observations.data.map((observation) => (
                                <div
                                    key={observation.id}
                                    className="flex flex-wrap items-center justify-between gap-4 p-5"
                                >
                                    <div>
                                        <Link
                                            href={`/my/observations/${observation.id}/edit`}
                                            className="font-semibold text-slate-900 hover:text-cyan-700"
                                        >
                                            {observation.title || 'Untitled draft'}
                                        </Link>
                                        <p className="mt-1 text-xs text-slate-500">
                                            Updated{' '}
                                            {new Date(
                                                observation.updated_at,
                                            ).toLocaleDateString()}
                                        </p>
                                    </div>

                                    <div className="flex items-center gap-3">
                                        <span
                                            className={`rounded-full px-3 py-1 text-xs font-medium ${
                                                statusStyles[observation.status]
                                                ?? statusStyles.draft
                                            }`}
                                        >
                                            {observation.status.replaceAll('_', ' ')}
                                        </span>

                                        {observation.status === 'draft' && (
                                            <button
                                                type="button"
                                                onClick={() =>
                                                    archiveDraft(observation)
                                                }
                                                className="text-sm font-medium text-slate-600 hover:underline"
                                            >
                                                Archive
                                            </button>
                                        )}
                                    </div>
                                </div>
                            ))}
                        </div>
                    )}

                    <footer className="flex flex-wrap items-center justify-between gap-3 border-t border-slate-200 p-5 text-sm text-slate-500">
                        <span>
                            Showing {observations.from ?? 0}–
                            {observations.to ?? 0} of {observations.total}
                        </span>

                        <nav aria-label="Observation pages" className="flex gap-2">
                            {previous?.url && (
                                <Link
                                    href={previous.url}
                                    className="rounded-lg border px-3 py-2 hover:bg-slate-50"
                                >
                                    Previous
                                </Link>
                            )}
                            {next?.url && (
                                <Link
                                    href={next.url}
                                    className="rounded-lg border px-3 py-2 hover:bg-slate-50"
                                >
                                    Next
                                </Link>
                            )}
                        </nav>
                    </footer>
                </section>
            </main>
        </>
    );
}
