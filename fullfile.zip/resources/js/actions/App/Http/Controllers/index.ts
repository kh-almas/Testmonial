import Admin from './Admin'
import MyObservationController from './MyObservationController'
import Settings from './Settings'
const Controllers = {
    Admin: Object.assign(Admin, Admin),
MyObservationController: Object.assign(MyObservationController, MyObservationController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers