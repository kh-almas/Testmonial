import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/my/observations',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MyObservationController::index
 * @see app/Http/Controllers/MyObservationController.php:40
 * @route '/my/observations'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/my/observations/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MyObservationController::create
 * @see app/Http/Controllers/MyObservationController.php:71
 * @route '/my/observations/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\MyObservationController::store
 * @see app/Http/Controllers/MyObservationController.php:78
 * @route '/my/observations'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/my/observations',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MyObservationController::store
 * @see app/Http/Controllers/MyObservationController.php:78
 * @route '/my/observations'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::store
 * @see app/Http/Controllers/MyObservationController.php:78
 * @route '/my/observations'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MyObservationController::store
 * @see app/Http/Controllers/MyObservationController.php:78
 * @route '/my/observations'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::store
 * @see app/Http/Controllers/MyObservationController.php:78
 * @route '/my/observations'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
export const edit = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/my/observations/{observation}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
edit.url = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { observation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    observation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        observation: args.observation,
                }

    return edit.definition.url
            .replace('{observation}', parsedArgs.observation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
edit.get = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
edit.head = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
    const editForm = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
        editForm.get = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\MyObservationController::edit
 * @see app/Http/Controllers/MyObservationController.php:95
 * @route '/my/observations/{observation}/edit'
 */
        editForm.head = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\MyObservationController::update
 * @see app/Http/Controllers/MyObservationController.php:107
 * @route '/my/observations/{observation}'
 */
export const update = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/my/observations/{observation}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\MyObservationController::update
 * @see app/Http/Controllers/MyObservationController.php:107
 * @route '/my/observations/{observation}'
 */
update.url = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { observation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    observation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        observation: args.observation,
                }

    return update.definition.url
            .replace('{observation}', parsedArgs.observation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::update
 * @see app/Http/Controllers/MyObservationController.php:107
 * @route '/my/observations/{observation}'
 */
update.put = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\MyObservationController::update
 * @see app/Http/Controllers/MyObservationController.php:107
 * @route '/my/observations/{observation}'
 */
    const updateForm = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::update
 * @see app/Http/Controllers/MyObservationController.php:107
 * @route '/my/observations/{observation}'
 */
        updateForm.put = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\MyObservationController::archive
 * @see app/Http/Controllers/MyObservationController.php:135
 * @route '/my/observations/{observation}/archive'
 */
export const archive = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

archive.definition = {
    methods: ["patch"],
    url: '/my/observations/{observation}/archive',
} satisfies RouteDefinition<["patch"]>

/**
* @see \App\Http\Controllers\MyObservationController::archive
 * @see app/Http/Controllers/MyObservationController.php:135
 * @route '/my/observations/{observation}/archive'
 */
archive.url = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { observation: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    observation: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        observation: args.observation,
                }

    return archive.definition.url
            .replace('{observation}', parsedArgs.observation.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\MyObservationController::archive
 * @see app/Http/Controllers/MyObservationController.php:135
 * @route '/my/observations/{observation}/archive'
 */
archive.patch = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: archive.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\MyObservationController::archive
 * @see app/Http/Controllers/MyObservationController.php:135
 * @route '/my/observations/{observation}/archive'
 */
    const archiveForm = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: archive.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PATCH',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MyObservationController::archive
 * @see app/Http/Controllers/MyObservationController.php:135
 * @route '/my/observations/{observation}/archive'
 */
        archiveForm.patch = (args: { observation: string | number } | [observation: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: archive.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    archive.form = archiveForm
const MyObservationController = { index, create, store, edit, update, archive }

export default MyObservationController