<?php

namespace App\Http\Controllers;

use App\Models\Testimonial;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\Validation\ValidationException;
use Inertia\Inertia;
use Inertia\Response;

class MyObservationController extends Controller
{
    private const SUBMISSION_TYPE = 'contributor';
    private const DRAFT = 'draft';
    private const CHANGES_REQUESTED = 'changes_requested';
    private const ARCHIVED = 'archived';

    private const CONTENT_FIELDS = [
        'title',
        'observation',
        'condition_symptom_text',
        'duration_text',
        'frequency_text',
        'timeline_text',
    ];

    private const EMPTY_RESEARCH = [
        'diseases' => [],
        'organs' => [],
        'systems' => [],
        'administration_methods' => [],
        'research_topics' => [],
        'keywords' => [],
        'biomarkers' => [],
    ];

    public function index(Request $request): Response
    {
        $this->userId($request);

        $validated = $request->validate([
            'search' => ['nullable', 'string', 'max:100'],
        ]);

        $search = trim($validated['search'] ?? '');

        $observations = $this->ownedObservations($request)
            ->when($search !== '', function (Builder $query) use ($search): void {
                $query->where('title', 'like', "%{$search}%");
            })
            ->latest('updated_at')
            ->paginate(10)
            ->withQueryString()
            ->through(fn (Testimonial $observation): array => [
                'id' => $observation->id,
                'title' => $observation->title,
                'status' => $observation->getRawOriginal('status'),
                'updated_at' => $observation->updated_at?->toIso8601String(),
            ]);

        return Inertia::render('observations/index', [
            'observations' => $observations,
            'filters' => ['search' => $search],
            'notice' => session('success'),
        ]);
    }

    public function create(Request $request): Response
    {
        $this->userId($request);

        return Inertia::render('observations/form', $this->formProps());
    }

    public function store(Request $request): RedirectResponse
    {
        $authorUserId = $this->userId($request);
        $validated = $this->validateDraft($request);

        $observation = new Testimonial();
        $this->fillContent($observation, $validated);
        $observation->author_user_id = $authorUserId;
        $observation->submission_type = self::SUBMISSION_TYPE;
        $observation->status = self::DRAFT;
        $observation->save();

        return to_route('my.observations.edit', [
            'observation' => $observation->id,
        ])->with('success', 'Draft saved.');
    }

    public function edit(Request $request, int $observation): Response
    {
        $existingObservation = $this->ownedObservations($request)
            ->whereKey($observation)
            ->firstOrFail();

        return Inertia::render(
            'observations/form',
            $this->formProps($existingObservation),
        );
    }

    public function update(Request $request, int $observation): RedirectResponse
    {
        $this->userId($request);
        $validated = $this->validateDraft($request);

        DB::transaction(function () use ($request, $observation, $validated): void {
            $existingObservation = $this->ownedObservations($request)
                ->whereKey($observation)
                ->lockForUpdate()
                ->firstOrFail();

            abort_unless(
                in_array(
                    $existingObservation->getRawOriginal('status'),
                    [self::DRAFT, self::CHANGES_REQUESTED],
                    true,
                ),
                409,
                'This observation cannot be edited in its current status.',
            );

            $this->fillContent($existingObservation, $validated);
            $existingObservation->save();
        });

        return back()->with('success', 'Changes saved.');
    }

    public function archive(Request $request, int $observation): RedirectResponse
    {
        $actorUserId = $this->userId($request);

        DB::transaction(function () use ($request, $observation, $actorUserId): void {
            $existingObservation = $this->ownedObservations($request)
                ->whereKey($observation)
                ->lockForUpdate()
                ->firstOrFail();

            abort_unless(
                $existingObservation->getRawOriginal('status') === self::DRAFT,
                409,
                'Only an unsubmitted draft can be archived.',
            );

            $existingObservation->status = self::ARCHIVED;
            $existingObservation->archived_by_user_id = $actorUserId;
            $existingObservation->archived_at = now();
            $existingObservation->save();
        });

        return to_route('my.observations.index')
            ->with('success', 'Draft archived.');
    }

    private function ownedObservations(Request $request): Builder
    {
        return Testimonial::query()
            ->where('author_user_id', $this->userId($request))
            ->where('submission_type', self::SUBMISSION_TYPE);
    }

    private function userId(Request $request): int
    {
        abort_unless($request->user(), 401);

        return (int) $request->user()->getAuthIdentifier();
    }

    private function validateDraft(Request $request): array
    {
        $validated = $request->validate([
            'title' => ['nullable', 'string', 'max:255'],
            'observation' => ['nullable', 'string'],
            'condition_symptom_text' => ['nullable', 'string', 'max:500'],
            'duration_text' => ['nullable', 'string', 'max:255'],
            'frequency_text' => ['nullable', 'string', 'max:255'],
            'timeline_text' => ['nullable', 'string'],
            'research' => ['sometimes', 'array'],
            'research.*' => ['array'],
        ]);

        foreach ($validated['research'] ?? [] as $selectedIds) {
            if ($selectedIds !== []) {
                throw ValidationException::withMessages([
                    'research' => 'Research selections are not available yet.',
                ]);
            }
        }

        return $validated;
    }

    private function fillContent(Testimonial $observation, array $validated): void
    {
        foreach (self::CONTENT_FIELDS as $fieldName) {
            $observation->{$fieldName} = $validated[$fieldName] ?? null;
        }
    }

    private function formProps(?Testimonial $observation = null): array
    {
        return [
            'observation' => $observation ? [
                'id' => $observation->id,
                'status' => $observation->getRawOriginal('status'),
                'title' => $observation->title,
                'observation' => $observation->observation,
                'condition_symptom_text' => $observation->condition_symptom_text,
                'duration_text' => $observation->duration_text,
                'frequency_text' => $observation->frequency_text,
                'timeline_text' => $observation->timeline_text,
                'research' => self::EMPTY_RESEARCH,
            ] : null,
            'groups' => [],
            'emptySelections' => self::EMPTY_RESEARCH,
            'history' => [],
            'notice' => session('success'),
        ];
    }
}
